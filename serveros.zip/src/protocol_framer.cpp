#include "protocol/framer.hpp"

namespace protocol
{

    LineFramer::LineFramer(std::size_t max_line, std::size_t max_buffer) : max_line_(max_line), max_buffer_(max_buffer)
    {
        buf_.reserve(512);
    }

    void LineFramer::feed(const char *data, std::size_t n)
    {
        if (overflow_)
        {
            return;
        }

        buf_.append(data, n);

        // Protect against unbounded growth without newline
        if (buf_.size() > max_buffer_)
        {
            overflow_ = true;
        }
    }

    std::vector<std::string> LineFramer::pop_lines()
    {
        std::vector<std::string> out;
        if (overflow_)
        {
            return out;
        }

        while (true)
        {
            auto pos = buf_.find('\n');
            if (pos == std::string::npos)
            {
                break;
            }

            std::string line = buf_.substr(0, pos);
            buf_.erase(0, pos + 1);

            // enforce per-line length (payload length)
            if (line.size() > max_line_)
            {
                overflow_ = true;
                out.clear();
                return out;
            }

            out.push_back(std::move(line));
        }
        return out;
    }

}