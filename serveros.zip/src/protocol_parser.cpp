#include "protocol/parser.hpp"
#include <cctype>
#include <optional>

namespace protocol
{

    std::string Parser::to_lower(std::string s)
    {
        for (auto &ch : s)
            ch = char(std::tolower((unsigned char)ch));
        return s;
    }

    static std::string trim_ws(std::string s)
    {
        auto is_ws = [](unsigned char c)
        {
            return c == ' ' || c == '\t' || c == '\n' || c == '\r';
        };

        std::size_t start = 0;
        while (start < s.size() && is_ws((unsigned char)s[start]))
            ++start;

        std::size_t end = s.size();
        while (end > start && is_ws((unsigned char)s[end - 1]))
            --end;

        return s.substr(start, end - start);
    }

    static std::vector<std::string> split_pipe(const std::string &s)
    {
        std::vector<std::string> out;
        std::string cur;
        for (char c : s)
        {
            if (c == '|')
            {
                out.push_back(cur);
                cur.clear();
            }
            else
                cur.push_back(c);
        }
        out.push_back(cur);
        return out;
    }

    std::optional<Message> Parser::parse_line(const std::string &line_in, std::string &out_error_details)
    {
        out_error_details.clear();

        // tolerate CRLF and accidental leading/trailing whitespace
        std::string line = line_in;
        if (!line.empty() && line.back() == '\r')
            line.pop_back();
        line = trim_ws(line);

        if (line.empty())
            return std::nullopt;

        if (line[0] != '/')
        {
            out_error_details = "expected_/cmd";
            return std::nullopt;
        }

        auto parts = split_pipe(line);
        if (parts.empty())
        {
            out_error_details = "empty";
            return std::nullopt;
        }

        std::string head = trim_ws(parts[0]); // "/cmd"
        if (head.size() < 2)
        {
            out_error_details = "missing_cmd";
            return std::nullopt;
        }

        Message msg;
        msg.cmd = to_lower(trim_ws(head.substr(1)));
        msg.args.clear();
        msg.args.reserve(parts.size() > 1 ? parts.size() - 1 : 0);
        for (std::size_t i = 1; i < parts.size(); ++i)
        {
            msg.args.push_back(trim_ws(parts[i]));
        }

        return msg;
    }

}
