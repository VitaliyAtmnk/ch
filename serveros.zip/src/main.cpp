#include "config.hpp"
#include "server/server.hpp"

int main()
{
    cfg::Config cfg;
    server::Server srv(cfg);
    return srv.start();
}
