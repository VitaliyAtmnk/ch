#include "net/connection.hpp"
#include <fcntl.h>
#include <sys/socket.h>
#include <unistd.h>
#include <cerrno>

namespace net
{

    static constexpr std::size_t RECV_BUF = 4096;

    bool Connection::set_nonblocking(int fd)
    {
        int flags = ::fcntl(fd, F_GETFL, 0);
        if (flags < 0)
            return false;
        return ::fcntl(fd, F_SETFL, flags | O_NONBLOCK) == 0;
    }

    Connection::Connection(int fd, std::size_t max_line, std::size_t max_buffer)
        : fd_(fd), framer_(max_line, max_buffer)
    {
        outbuf_.reserve(1024);
        set_nonblocking(fd_);
    }

    Connection::~Connection()
    {
        if (fd_ >= 0)
            ::close(fd_);
    }

    bool Connection::read_into_framer()
    {
        char buf[RECV_BUF];
        while (true)
        {
            ssize_t n = ::recv(fd_, buf, sizeof(buf), 0);
            if (n > 0)
            {
                framer_.feed(buf, (std::size_t)n);
                if (framer_.buffer_overflow())
                    return false;
                continue;
            }
            if (n == 0)
                return false; // peer closed
            if (errno == EAGAIN || errno == EWOULDBLOCK)
                return true;
            return false;
        }
    }

    void Connection::send_line(const std::string &line_no_nl)
    {
        outbuf_.append(line_no_nl);
        outbuf_.push_back('\n');
    }

    bool Connection::flush()
    {
        while (!outbuf_.empty())
        {
            ssize_t n = ::send(fd_, outbuf_.data(), outbuf_.size(), 0);
            if (n > 0)
            {
                outbuf_.erase(0, (std::size_t)n);
                continue;
            }
            if (errno == EAGAIN || errno == EWOULDBLOCK)
                return true;
            return false;
        }
        return true;
    }

}