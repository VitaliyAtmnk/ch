#include "server/server.hpp"
#include <iostream>
#include <sstream>

#include <cctype>
#include <vector>

#include <cerrno>
#include <cstring>

#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <spdlog/spdlog.h>
#include <spdlog/async.h>
#include <spdlog/sinks/basic_file_sink.h>
#include <spdlog/sinks/stdout_color_sinks.h>

namespace server
{

    static std::string sanitize_line(const std::string &s)
    {
        std::string out;
        out.reserve(s.size());
        for (char c : s)
        {
            if (c == '\n')
                out += "\\n";
            else if (c == '\r')
                out += "\\r";
            else
                out.push_back(c);
        }
        return out;
    }

    static bool set_nonblocking_fd(int fd)
    {
        int flags = ::fcntl(fd, F_GETFL, 0);
        if (flags < 0)
            return false;
        return ::fcntl(fd, F_SETFL, flags | O_NONBLOCK) == 0;
    }

    static std::string peer_string(int fd)
    {
        sockaddr_storage ss;
        socklen_t slen = sizeof(ss);
        if (::getpeername(fd, reinterpret_cast<sockaddr *>(&ss), &slen) != 0)
            return "?";

        char ip[INET6_ADDRSTRLEN] = {0};
        int port = 0;

        if (ss.ss_family == AF_INET)
        {
            auto *sin = reinterpret_cast<sockaddr_in *>(&ss);
            ::inet_ntop(AF_INET, &sin->sin_addr, ip, sizeof(ip));
            port = ntohs(sin->sin_port);
        }
        else if (ss.ss_family == AF_INET6)
        {
            auto *sin6 = reinterpret_cast<sockaddr_in6 *>(&ss);
            ::inet_ntop(AF_INET6, &sin6->sin6_addr, ip, sizeof(ip));
            port = ntohs(sin6->sin6_port);
        }
        else
        {
            return "?";
        }

        std::ostringstream oss;
        oss << ip << ":" << port;
        return oss.str();
    }

    static std::shared_ptr<spdlog::logger> make_logger()
    {
        try
        {
            // Async logger so that high-volume TX/RX logs don't stall the server.
            try
            {
                spdlog::init_thread_pool(8192, 1);
            }
            catch (...)
            {
            }

            auto console_sink = std::make_shared<spdlog::sinks::stdout_color_sink_mt>();
            auto file_sink = std::make_shared<spdlog::sinks::basic_file_sink_mt>("server.log", true);
            std::vector<spdlog::sink_ptr> sinks{console_sink, file_sink};

            auto logger = std::make_shared<spdlog::async_logger>(
                "server",
                sinks.begin(),
                sinks.end(),
                spdlog::thread_pool(),
                spdlog::async_overflow_policy::overrun_oldest);

            logger->set_pattern("[%Y-%m-%d %H:%M:%S.%e] [%^%l%$] [t%t] %v");
            logger->set_level(spdlog::level::info);
            spdlog::register_logger(logger);
            return logger;
        }
        catch (...)
        {
            // Fallback to default logger (still thread-safe).
            return spdlog::default_logger();
        }
    }

    static std::string to_lower(std::string s)
    {
        for (auto &ch : s)
            ch = char(std::tolower((unsigned char)ch));
        return s;
    }

    Server::Server(cfg::Config cfg) : cfg_(cfg)
    {
        log_ = make_logger();

        // Wake-up pipe for poll(): worker threads can notify the main thread immediately.
        int p[2];
        if (::pipe(p) == 0)
        {
            wake_r_ = p[0];
            wake_w_ = p[1];
            set_nonblocking_fd(wake_r_);
            set_nonblocking_fd(wake_w_);
        }

        create_commands();
    }

    int Server::start()
    {
        if (!listener_.open(cfg_.port, cfg_.backlog))
            return 1;
        if (log_)
            log_->info("listening on 0.0.0.0:{} (poll_timeout_ms={})", cfg_.port, cfg_.poll_timeout_ms);
        else
            std::cout << "Listening on 0.0.0.0:" << cfg_.port << "\n";

        while (true)
        {
            accept_clients();
            drain_outgoing();
            rebuild_pollset();

            for (auto &ev : poller_.poll(cfg_.poll_timeout_ms))
            {
                on_event(ev);
            }

            // Game threads may have produced output / end-game events.
            drain_outgoing();
            ka_tick();

            // Keep-alive sends may have queued data too.
            drain_outgoing();
        }
    }

    void Server::create_commands()
    {
        handlers_.clear();
        handlers_["hello"] = [this](int fd, const protocol::Message &m)
        { cmd_hello(fd, m); };
        handlers_["ping"] = [this](int fd, const protocol::Message &m)
        { cmd_ping(fd, m); };
        handlers_["pong"] = [this](int fd, const protocol::Message &m)
        { cmd_pong(fd, m); };
        handlers_["exit"] = [this](int fd, const protocol::Message &m)
        { cmd_exit(fd, m); };
        handlers_["nick"] = [this](int fd, const protocol::Message &m)
        { cmd_nick(fd, m); };
        handlers_["reconnect"] = [this](int fd, const protocol::Message &m)
        { cmd_reconnect(fd, m); };
        handlers_["queue"] = [this](int fd, const protocol::Message &m)
        { cmd_queue(fd, m); };
        handlers_["leave-queue"] = [this](int fd, const protocol::Message &m)
        { cmd_leave_queue(fd, m); };
        handlers_["move"] = [this](int fd, const protocol::Message &m)
        { cmd_move(fd, m); };
        handlers_["resign"] = [this](int fd, const protocol::Message &m)
        { cmd_resign(fd, m); };
    }

    void Server::accept_clients()
    {
        while (true)
        {
            int cfd = listener_.accept_one();
            if (cfd < 0)
                break;
            conns_[cfd] = std::make_unique<net::Connection>(cfd, cfg_.max_line, cfg_.max_buffer);
            peers_[cfd] = peer_string(cfd);
            ka_on_connected(cfd);
            if (log_)
                log_->info("client connected fd={} peer={}", cfd, peers_[cfd]);
            std::string hello = "/hello|chess|" + std::to_string(cfg_.version);
            send_fd(cfd, hello);
        }
    }

    void Server::request_close_fd(int fd)
    {
        if (conns_.find(fd) == conns_.end())
            return;

        closing_fds_.insert(fd);
        finalize_graceful_close(fd);
    }

    void Server::mark_close_cause(int fd, CloseCause cause)
    {
        if (fd < 0)
            return;
        close_causes_[fd] = cause;
    }

    Server::CloseCause Server::consume_close_cause(int fd)
    {
        auto it = close_causes_.find(fd);
        if (it == close_causes_.end())
            return CloseCause::Disconnected;

        CloseCause c = it->second;
        close_causes_.erase(it);
        return c;
    }

    void Server::finalize_graceful_close(int fd)
    {
        if (!closing_fds_.count(fd))
            return;

        auto it = conns_.find(fd);
        if (it == conns_.end())
        {
            closing_fds_.erase(fd);
            return;
        }

        if (!it->second->has_pending_output())
        {
            close_fd(fd);
        }
    }

    void Server::rebuild_pollset()
    {
        poller_.clear();
        poller_.add_fd(listener_.fd(), true, false);

        if (wake_r_ >= 0)
            poller_.add_fd(wake_r_, true, false);

        for (auto &kv : conns_)
        {
            int fd = kv.first;
            bool want_write = kv.second->has_pending_output();
            poller_.add_fd(fd, true, want_write);
        }
    }

    void Server::on_event(const net::PollEvent &e)
    {
        if (e.fd == listener_.fd())
        {
            if (e.readable)
                accept_clients();
            return;
        }

        if (wake_r_ >= 0 && e.fd == wake_r_)
        {
            if (e.readable)
            {
                // Drain the pipe (non-blocking) to clear the wake signal.
                char buf[128];
                while (::read(wake_r_, buf, sizeof(buf)) > 0)
                {
                }
            }
            return;
        }

        auto it = conns_.find(e.fd);
        if (it == conns_.end())
            return;

        if (e.error)
        {
            if (log_)
                log_->warn("poll error on fd={} (peer={})", e.fd, peers_.count(e.fd) ? peers_[e.fd] : "?");
            close_fd(e.fd);
            return;
        }

        if (e.readable)
        {
            if (!it->second->read_into_framer())
            {
                close_fd(e.fd);
                return;
            }
            ka_note_activity(e.fd);

            auto lines = it->second->pop_lines();
            if (it->second->framer_overflow())
            {
                close_fd(e.fd);
                return;
            }

            for (auto &line : lines)
            {
                handle_line(e.fd, line);
                if (conns_.find(e.fd) == conns_.end())
                    return;
            }
        }

        if (e.writable)
        {
            auto itw = conns_.find(e.fd);
            if (itw != conns_.end())
            {
                if (!itw->second->flush())
                {
                    if (log_)
                        log_->warn("flush failed fd={} (peer={})", e.fd, peers_.count(e.fd) ? peers_[e.fd] : "?");
                    close_fd(e.fd);
                    return;
                }
            }
        }

        if (conns_.find(e.fd) != conns_.end())
        {
            finalize_graceful_close(e.fd);
        }
    }

    void Server::handle_line(int fd, const std::string &line)
    {
        const std::string raw = sanitize_line(line);

        std::string details;
        auto msg_opt = protocol::Parser::parse_line(line, details);
        if (!msg_opt)
        {
            if (log_)
                log_->warn("RX bad_format fd={} peer={} line='{}' details='{}'",
                           fd,
                           peers_.count(fd) ? peers_[fd] : "?",
                           raw,
                           details);
            auto *s = session_for_fd(fd);
            protocol_strike(s, fd, err::Code::BadFormat, details);
            return;
        }

        if (log_)
        {
            auto *s = session_for_fd(fd);
            const std::string tok = s ? s->token : "";
            const std::string nick = s ? s->nickname : "";
            log_->info("RX fd={} peer={} cmd={} nick={} token={} line='{}'",
                       fd,
                       peers_.count(fd) ? peers_[fd] : "?",
                       msg_opt->cmd,
                       nick.empty() ? "-" : nick,
                       tok.empty() ? "-" : tok.substr(0, 6),
                       raw);
        }
        dispatch(fd, *msg_opt);
    }

    void Server::dispatch(int fd, const protocol::Message &msg)
    {
        auto it = handlers_.find(msg.cmd);
        if (it == handlers_.end())
        {
            auto *s = session_for_fd(fd);
            protocol_strike(s, fd, err::Code::UnknownCommand, msg.cmd);
            return;
        }
        it->second(fd, msg);
    }

    void Server::send_fd(int fd, const std::string &line)
    {
        auto it = conns_.find(fd);
        if (it == conns_.end())
            return;

        if (log_)
        {
            auto *s = session_for_fd(fd);
            const std::string tok = s ? s->token : "";
            const std::string nick = s ? s->nickname : "";
            log_->info("TX fd={} peer={} nick={} token={} line='{}'",
                       fd,
                       peers_.count(fd) ? peers_[fd] : "?",
                       nick.empty() ? "-" : nick,
                       tok.empty() ? "-" : tok.substr(0, 6),
                       sanitize_line(line));
        }
        it->second->send_line(line);
    }

    void Server::enqueue_outgoing(Outgoing o)
    {
        {
            std::lock_guard<std::mutex> lk(out_mtx_);
            out_q_.push_back(std::move(o));
        }

        // Wake up poll() so the output is delivered immediately (no extra latency from poll_timeout_ms).
        if (wake_w_ >= 0)
        {
            const char b = 'x';
            (void)::write(wake_w_, &b, 1);
        }
    }

    void Server::drain_outgoing()
    {
        std::deque<Outgoing> local;
        {
            std::lock_guard<std::mutex> lk(out_mtx_);
            if (out_q_.empty())
                return;
            local.swap(out_q_);
        }

        for (auto &o : local)
        {
            switch (o.kind)
            {
            case Outgoing::Kind::SendToFd:
                if (o.fd >= 0)
                    send_fd(o.fd, o.line);
                break;
            case Outgoing::Kind::SendToToken:
            {
                auto *s = session_by_token(o.token);
                if (s && s->fd >= 0)
                    send_fd(s->fd, o.line);
                else if (log_)
                    log_->info("drop TX to offline token={} line='{}'", o.token.empty() ? "-" : o.token.substr(0, 6), sanitize_line(o.line));
                break;
            }
            case Outgoing::Kind::StrikeProtocol:
            {
                auto *s = session_by_token(o.token);
                if (s)
                    add_protocol_strike(*s);
                break;
            }
            case Outgoing::Kind::StrikeGame:
            {
                auto *s = session_by_token(o.token);
                if (s)
                    add_game_strike(*s);
                break;
            }
            case Outgoing::Kind::EndWin:
                end_game_with_winner(o.game_id, o.winner_token, o.reason);
                break;
            case Outgoing::Kind::EndDraw:
                end_game_draw(o.game_id, o.reason);
                break;
            }
        }
    }

    std::string Server::token_for_fd(int fd) const
    {
        auto it = fd_to_token_.find(fd);
        if (it == fd_to_token_.end())
            return "";
        return it->second;
    }

    domain::PlayerSession *Server::session_for_fd(int fd)
    {
        std::string t = token_for_fd(fd);
        if (t.empty())
            return nullptr;
        return &sessions_.at(t);
    }

    domain::PlayerSession *Server::session_by_token(const std::string &token)
    {
        auto it = sessions_.find(token);
        if (it == sessions_.end())
            return nullptr;
        return &it->second;
    }

    std::string Server::new_token()
    {
        static const char *abc = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        std::uniform_int_distribution<int> dist(0, 61);
        std::string t;
        t.reserve(24);
        for (int i = 0; i < 24; ++i)
            t.push_back(abc[dist(rng_)]);
        return t;
    }

    bool Server::is_nick_ok(const std::string &s)
    {
        if (s.empty() || s.size() > 16)
            return false;
        for (unsigned char ch : s)
        {
            if (!(std::isalnum(ch) || ch == '_'))
                return false;
        }
        return true;
    }

    void Server::cmd_hello(int fd, const protocol::Message &msg)
    {
        // Spec: /hello|client|1
        if (msg.args.size() != 2)
        {
            protocol_strike(session_for_fd(fd), fd, err::Code::BadFormat, "hello");
            return;
        }

        std::string who = to_lower(msg.args[0]);
        std::string ver = msg.args[1];

        if (who == "client" && ver == std::to_string(cfg_.version))
        {
            // No-op: server už poslal /hello|chess|1 při acceptu.
            return;
        }

        protocol_strike(session_for_fd(fd), fd, err::Code::BadFormat, "hello");
    }

    // -------- strikes & kick --------

    void Server::send_move_ack_ok(int fd, int game_id)
    {
        send_fd(fd, "/move-ack|" + std::to_string(game_id) + "|ok");
    }

    void Server::send_move_ack_err(int fd, int game_id, const std::string &reason)
    {
        send_fd(fd, "/move-ack|" + std::to_string(game_id) + "|err|" + reason);
    }

    void Server::add_protocol_strike(domain::PlayerSession &s)
    {
        s.protocol_strikes++;
        if (log_)
            log_->warn("protocol strike nick={} token={} count={}/{}",
                       s.nickname.empty() ? "-" : s.nickname,
                       s.token.substr(0, 6),
                       s.protocol_strikes,
                       cfg_.protocol_strikes_max);
        if (s.protocol_strikes > cfg_.protocol_strikes_max)
        {
            kick(s, "too_many_errors");
        }
    }

    void Server::add_game_strike(domain::PlayerSession &s)
    {
        s.game_strikes++;
        if (log_)
            log_->warn("game strike nick={} token={} count={}/{}",
                       s.nickname.empty() ? "-" : s.nickname,
                       s.token.substr(0, 6),
                       s.game_strikes,
                       cfg_.game_strikes_max);
        if (s.game_strikes > cfg_.game_strikes_max)
        {
            kick(s, "too_many_errors");
        }
    }

    void Server::protocol_strike(domain::PlayerSession *s, int fd, err::Code code, const std::string &details)
    {
        send_fd(fd, err::line(code, details));

        if (!s)
        {
            // no session yet -> strict: close on repeated protocol abuse is ok
            return;
        }
        add_protocol_strike(*s);
    }

    void Server::game_strike(domain::PlayerSession &s, int fd, int game_id, const std::string &reason)
    {
        send_move_ack_err(fd, game_id, reason);
        add_game_strike(s);
    }

    void Server::kick(domain::PlayerSession &s, const std::string &reason)
    {
        if (s.fd >= 0)
        {
            send_fd(s.fd, "/kick|reason|" + reason);

            mark_close_cause(s.fd, CloseCause::Kicked);

            request_close_fd(s.fd);
        }
    }

    // -------- connection close / disconnect policy --------

    void Server::close_fd(int fd)
    {
        closing_fds_.erase(fd);
        CloseCause cause = consume_close_cause(fd);

        if (log_)
            log_->info("client disconnected fd={} peer={} cause={}",
                       fd,
                       peers_.count(fd) ? peers_[fd] : "?",
                       (cause == CloseCause::Kicked) ? "kicked" : (cause == CloseCause::ClientExit) ? "client_exit"
                                                                                                    : "disconnected");

        // if this fd belongs to a session, handle disconnect policy
        domain::PlayerSession *s = session_for_fd(fd);
        if (s)
        {
            // free name reservation
            if (!s->nickname.empty())
                names_in_use_.erase(s->nickname);

            if (s->state == domain::ConnState::Game && s->game_id >= 0)
            {
                handle_disconnect_in_game(*s, s->game_id, cause);
            }

            // session remains (token reusable), but becomes offline + connected state
            s->fd = -1;
            s->state = domain::ConnState::Connected;
            s->color = domain::Color::None;
            s->game_id = -1;
        }

        fd_to_token_.erase(fd);
        peers_.erase(fd);

        ka_on_disconnected(fd);
        conns_.erase(fd); // Connection dtor closes socket
    }

    // -------- matchmaking --------

    void Server::try_matchmake()
    {
        auto valid = [&](const std::string &token)
        {
            auto *s = session_by_token(token);
            return s && s->fd >= 0 && s->state == domain::ConnState::Queue;
        };

        std::string a, b;
        while (queue_.pop_two(a, b, valid))
        {
            start_game(a, b);
        }
    }

    void Server::start_game(const std::string &token_a, const std::string &token_b)
    {
        auto *A = session_by_token(token_a);
        auto *B = session_by_token(token_b);
        if (!A || !B)
            return;

        int gid = next_game_id_++;

        // randomize colors
        std::uniform_int_distribution<int> dist(0, 1);
        bool a_white = (dist(rng_) == 0);

        std::string white = a_white ? token_a : token_b;
        std::string black = a_white ? token_b : token_a;

        // Store lightweight game metadata in the main thread...
        games_.emplace(gid, GameMeta{white, black});

        auto *W = session_by_token(white);
        auto *K = session_by_token(black);
        if (!W || !K)
            return;

        // ...and spin up a worker thread that owns the chess logic for this game.
        auto emit = [this](Outgoing o)
        {
            enqueue_outgoing(std::move(o));
        };
        auto worker = std::make_unique<GameWorker>(gid, white, black, emit, log_);
        worker->start();
        game_workers_[gid] = std::move(worker);

        W->state = domain::ConnState::Game;
        W->game_id = gid;
        W->color = domain::Color::White;
        W->game_strikes = 0;
        K->state = domain::ConnState::Game;
        K->game_id = gid;
        K->color = domain::Color::Black;
        K->game_strikes = 0;

        send_fd(W->fd, "/game-start|" + std::to_string(gid) + "|opponent|" + K->nickname + "|color|white|turn|white");
        send_fd(K->fd, "/game-start|" + std::to_string(gid) + "|opponent|" + W->nickname + "|color|black|turn|white");

        // Initial board state (start position)
        domain::Game tmp(gid);
        tmp.set_players(white, black);
        const std::string start_fen = tmp.fen();

        send_fd(W->fd, "/state|" + std::to_string(gid) + "|" + start_fen + "|turn|white");
        send_fd(K->fd, "/state|" + std::to_string(gid) + "|" + start_fen + "|turn|white");
    }

    // -------- end game helpers --------

    void Server::end_game_with_winner(int game_id, const std::string &winner_token, const std::string &reason)
    {
        auto git = games_.find(game_id);
        if (git == games_.end())
            return;

        std::string white = git->second.white_token;
        std::string black = git->second.black_token;
        std::string loser = (winner_token == white) ? black : white;

        auto *W = session_by_token(winner_token);
        auto *L = session_by_token(loser);

        if (W && W->fd >= 0)
            send_fd(W->fd, "/game-end|" + std::to_string(game_id) + "|win|reason|" + reason);
        if (L && L->fd >= 0)
            send_fd(L->fd, "/game-end|" + std::to_string(game_id) + "|lose|reason|" + reason);

        if (W)
        {
            W->state = domain::ConnState::Lobby;
            W->game_id = -1;
            W->color = domain::Color::None;
        }
        if (L)
        {
            L->state = domain::ConnState::Lobby;
            L->game_id = -1;
            L->color = domain::Color::None;
        }

        games_.erase(git);

        // Stop & reap the worker thread.
        auto wit = game_workers_.find(game_id);
        if (wit != game_workers_.end())
        {
            wit->second->stop();
            game_workers_.erase(wit);
        }
    }

    void Server::end_game_draw(int game_id, const std::string &reason)
    {
        auto git = games_.find(game_id);
        if (git == games_.end())
            return;

        auto *A = session_by_token(git->second.white_token);
        auto *B = session_by_token(git->second.black_token);

        if (A && A->fd >= 0)
            send_fd(A->fd, "/game-end|" + std::to_string(game_id) + "|draw|reason|" + reason);
        if (B && B->fd >= 0)
            send_fd(B->fd, "/game-end|" + std::to_string(game_id) + "|draw|reason|" + reason);

        if (A)
        {
            A->state = domain::ConnState::Lobby;
            A->game_id = -1;
            A->color = domain::Color::None;
        }
        if (B)
        {
            B->state = domain::ConnState::Lobby;
            B->game_id = -1;
            B->color = domain::Color::None;
        }

        games_.erase(git);

        // Stop & reap the worker thread.
        auto wit = game_workers_.find(game_id);
        if (wit != game_workers_.end())
        {
            wit->second->stop();
            game_workers_.erase(wit);
        }
    }

    void Server::handle_disconnect_in_game(domain::PlayerSession &leaver, int game_id, CloseCause cause)
    {
        auto git = games_.find(game_id);
        if (git == games_.end())
            return;

        std::string winner =
            (leaver.token == git->second.white_token) ? git->second.black_token
                                                      : git->second.white_token;

        const char *reason;

        switch (cause)
        {
        case CloseCause::Kicked:
            reason = "opponent_kicked";
            break;

        case CloseCause::Disconnected:
            reason = "opponent_disconnected";
            break;

        case CloseCause::ClientExit:
            reason = "opponent_left";
            break;

        default:
            reason = "opponent_magically_disappeared";
        }

        end_game_with_winner(game_id, winner, reason);
    }

    // -------- commands --------

    void Server::cmd_ping(int fd, const protocol::Message &msg)
    {
        std::string nonce = msg.args.empty() ? "" : msg.args[0];
        send_fd(fd, "/pong|" + nonce);
    }

    void Server::cmd_pong(int fd, const protocol::Message &msg)
    {
        const std::string nonce = msg.args.empty() ? "" : msg.args[0];
        ka_note_pong(fd, nonce);
    }

    void Server::cmd_exit(int fd, const protocol::Message &)
    {

        mark_close_cause(fd, CloseCause::ClientExit);
        send_fd(fd, "/bye");
        request_close_fd(fd);
    }

    void Server::cmd_nick(int fd, const protocol::Message &msg)
    {
        if (msg.args.size() != 1)
        {
            protocol_strike(session_for_fd(fd), fd, err::Code::BadFormat, "nick");
            return;
        }
        // already has session?
        if (session_for_fd(fd))
        {
            send_fd(fd, err::line(err::Code::NickAlreadySet));
            return;
        }

        std::string nick = msg.args[0];
        if (!is_nick_ok(nick))
        {
            send_fd(fd, err::line(err::Code::NickInvalid));
            return;
        }
        if (names_in_use_.count(nick))
        {
            send_fd(fd, err::line(err::Code::NickInUse));
            return;
        }

        domain::PlayerSession s;
        s.token = new_token();
        s.nickname = nick;
        s.fd = fd;
        s.state = domain::ConnState::Lobby;

        names_in_use_.insert(nick);
        sessions_.emplace(s.token, s);

        fd_to_token_[fd] = s.token;

        send_fd(fd, "/nick-ack|" + nick + "|" + s.token);
    }

    void Server::cmd_reconnect(int fd, const protocol::Message &msg)
    {
        if (msg.args.size() != 1)
        {
            protocol_strike(session_for_fd(fd), fd, err::Code::BadFormat, "reconnect");
            return;
        }
        if (session_for_fd(fd))
        {
            send_fd(fd, err::line(err::Code::IllegalInState, "already_authed"));
            return;
        }
        std::string token = msg.args[0];
        auto it = sessions_.find(token);
        if (it == sessions_.end())
        {
            send_fd(fd, err::line(err::Code::ReconnectFailed));
            return;
        }

        // single-login: if session is online elsewhere, drop old
        if (it->second.fd >= 0 && it->second.fd != fd)
        {
            close_fd(it->second.fd);
        }

        it->second.fd = fd;
        it->second.state = domain::ConnState::Lobby;
        it->second.protocol_strikes = 0;
        it->second.game_strikes = 0;

        names_in_use_.insert(it->second.nickname);

        fd_to_token_[fd] = token;

        send_fd(fd, "/reconnect-ack|" + it->second.nickname + "|state|lobby");
    }

    void Server::cmd_queue(int fd, const protocol::Message &)
    {
        auto *s = session_for_fd(fd);
        if (!s)
        {
            send_fd(fd, err::line(err::Code::Unauthorized, "need_nick"));
            return;
        }

        if (s->state == domain::ConnState::Lobby)
        {
            s->state = domain::ConnState::Queue;
            queue_.enqueue(s->token);
            send_fd(fd, "/queue-ack");
            try_matchmake();
            return;
        }
        if (s->state == domain::ConnState::Queue)
        {
            send_fd(fd, err::line(err::Code::AlreadyInQueue));
            return;
        }
        send_fd(fd, err::line(err::Code::IllegalInState));
    }

    void Server::cmd_leave_queue(int fd, const protocol::Message &)
    {
        auto *s = session_for_fd(fd);
        if (!s)
        {
            send_fd(fd, err::line(err::Code::Unauthorized, "need_nick"));
            return;
        }

        if (s->state != domain::ConnState::Queue)
        {
            send_fd(fd, err::line(err::Code::NotInQueue));
            return;
        }

        s->state = domain::ConnState::Lobby;
        queue_.remove(s->token);
        send_fd(fd, "/leave-queue-ack");
    }
    void Server::cmd_move(int fd, const protocol::Message &msg)
    {
        int gid_hint = 0;
        if (!msg.args.empty())
        {
            try
            {
                gid_hint = std::stoi(msg.args[0]);
            }
            catch (...)
            {
                gid_hint = 0;
            }
        }

        auto *s = session_for_fd(fd);
        if (!s)
        {
            // Always answer /move with /move-ack
            send_move_ack_err(fd, gid_hint, "unauthorized");
            return;
        }

        if (s->state != domain::ConnState::Game)
        {
            send_move_ack_err(fd, gid_hint, "not_in_game");
            add_protocol_strike(*s);
            return;
        }

        if (!(msg.args.size() == 3 || msg.args.size() == 4))
        {
            send_move_ack_err(fd, gid_hint, "bad_format");
            add_protocol_strike(*s);
            return;
        }

        int gid = -1;
        try
        {
            gid = std::stoi(msg.args[0]);
        }
        catch (...)
        {
            send_move_ack_err(fd, 0, "bad_gameid");
            add_protocol_strike(*s);
            return;
        }

        if (gid != s->game_id)
        {
            send_move_ack_err(fd, gid, "bad_gameid");
            add_game_strike(*s);
            return;
        }

        auto git = games_.find(gid);
        if (git == games_.end())
        {
            send_move_ack_err(fd, gid, "bad_gameid");
            add_game_strike(*s);
            return;
        }

        const std::string &from = msg.args[1];
        const std::string &to = msg.args[2];
        const std::string promo = (msg.args.size() == 4) ? msg.args[3] : "";

        // The chess logic for each game runs on its own thread.
        // We only validate permissions/state in the main thread and enqueue the move.
        auto wit = game_workers_.find(gid);
        if (wit == game_workers_.end())
        {
            send_move_ack_err(fd, gid, "bad_gameid");
            add_game_strike(*s);
            return;
        }

        wit->second->post_move(fd, s->token, from, to, promo);
    }

    void Server::ka_on_connected(int fd)
    {
        KeepAliveState st;
        st.last_activity = Clock::now();
        keepalive_[fd] = st;
    }

    void Server::ka_on_disconnected(int fd)
    {
        keepalive_.erase(fd);
    }

    void Server::ka_note_activity(int fd)
    {
        auto it = keepalive_.find(fd);
        if (it == keepalive_.end())
            return;

        it->second.last_activity = Clock::now();

        it->second.awaiting_pong = false;
    }

    void Server::ka_note_pong(int fd, const std::string &nonce)
    {
        auto it = keepalive_.find(fd);
        if (it == keepalive_.end())
            return;

        //
        if (it->second.awaiting_pong && std::to_string(it->second.nonce) == nonce)
        {
            it->second.awaiting_pong = false;
            it->second.last_activity = Clock::now();
        }
    }

    void Server::ka_tick()
    {
        using namespace std::chrono;

        const auto now = Clock::now();
        const auto ping_iv = milliseconds(cfg_.ping_interval_ms);
        const auto pong_to = milliseconds(cfg_.pong_timeout_ms);
        const auto idle_to = milliseconds(cfg_.idle_drop_ms);

        std::vector<int> to_close;

        for (auto &[fd, st] : keepalive_)
        {
            // hard idle drop
            if (idle_to.count() > 0 && (now - st.last_activity) > idle_to)
            {
                to_close.push_back(fd);
                continue;
            }

            if (st.awaiting_pong)
            {
                if ((now - st.ping_sent_at) > pong_to)
                    to_close.push_back(fd);
                continue;
            }

            if ((now - st.last_activity) > ping_iv)
            {
                st.awaiting_pong = true;
                st.nonce = keepalive_nonce_++;
                st.ping_sent_at = now;
                send_fd(fd, "/ping|" + std::to_string(st.nonce));
            }
        }

        for (int fd : to_close)
        {
            // Time out
            close_fd(fd);
        }
    }

    void Server::cmd_resign(int fd, const protocol::Message &msg)
    {
        auto *s = session_for_fd(fd);
        if (!s)
        {
            send_fd(fd, err::line(err::Code::Unauthorized, "need_nick"));
            return;
        }
        if (s->state != domain::ConnState::Game)
        {
            send_fd(fd, err::line(err::Code::NotInGame));
            return;
        }

        if (msg.args.size() != 1)
        {
            protocol_strike(s, fd, err::Code::BadFormat, "resign");
            return;
        }

        int gid = -1;
        try
        {
            gid = std::stoi(msg.args[0]);
        }
        catch (...)
        {
            protocol_strike(s, fd, err::Code::BadFormat, "gameId");
            return;
        }
        if (gid != s->game_id)
        {
            send_fd(fd, err::line(err::Code::BadGameId));
            return;
        }

        auto git = games_.find(gid);
        if (git == games_.end())
        {
            send_fd(fd, err::line(err::Code::BadGameId));
            return;
        }

        std::string winner = (s->token == git->second.white_token) ? git->second.black_token
                                                                   : git->second.white_token;
        end_game_with_winner(gid, winner, "opponent_resigned");
    }

}