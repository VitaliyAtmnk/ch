#include "net/tcp_listener.hpp"
#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#include <cerrno>
#include <cstring>
#include <iostream>

namespace net
{

    TcpListener::~TcpListener()
    {
        if (fd_ >= 0)
            ::close(fd_);
    }

    bool TcpListener::set_nonblocking(int fd)
    {
        int flags = ::fcntl(fd, F_GETFL, 0);

        if (flags < 0)
        {
            return false;
        }

        return ::fcntl(fd, F_SETFL, flags | O_NONBLOCK) == 0;
    }

    bool TcpListener::open(int port, int backlog)
    {
        fd_ = ::socket(AF_INET, SOCK_STREAM, 0);

        if (fd_ < 0)
        {
            std::cerr << "socket: " << std::strerror(errno) << "\n";
            return false;
        }

        int opt = 1;
        ::setsockopt(fd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons((uint16_t)port);
        addr.sin_addr.s_addr = htonl(INADDR_ANY);

        if (::bind(fd_, reinterpret_cast<sockaddr *>(&addr), sizeof(addr)) < 0)
        {
            std::cerr << "bind: " << std::strerror(errno) << "\n";
            return false;
        }

        if (::listen(fd_, backlog) < 0)
        {
            std::cerr << "listen: " << std::strerror(errno) << "\n";
            return false;
        }

        if (!set_nonblocking(fd_))
        {
            std::cerr << "nonblocking(listen): " << std::strerror(errno) << "\n";
            return false;
        }

        return true;
    }

    int TcpListener::accept_one()
    {
        sockaddr_in caddr{};
        socklen_t clen = sizeof(caddr);
        int cfd = ::accept(fd_, reinterpret_cast<sockaddr *>(&caddr), &clen);
        if (cfd < 0)
        {
            if (errno == EAGAIN || errno == EWOULDBLOCK)
            {
                return -1;
            }

            return -1;
        }
        set_nonblocking(cfd);
        return cfd;
    }

}