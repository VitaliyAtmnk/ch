#include "net/poller.hpp"
#include <cerrno>

namespace net
{

    void Poller::clear()
    {
        pfds_.clear();
        index_.clear();
    }

    void Poller::add_fd(int fd, bool want_read, bool want_write)
    {
        pollfd p{};
        p.fd = fd;
        p.events = 0;
        if (want_read)
            p.events |= POLLIN;
        if (want_write)
            p.events |= POLLOUT;
        p.revents = 0;

        index_[fd] = pfds_.size();
        pfds_.push_back(p);
    }

    std::vector<PollEvent> Poller::poll(int timeout_ms)
    {
        std::vector<PollEvent> out;
        if (pfds_.empty())
        {
            return out;
        }

        int rc = ::poll(pfds_.data(), pfds_.size(), timeout_ms);
        if (rc <= 0)
        {
            return out;
        }

        out.reserve((std::size_t)rc);
        for (auto &p : pfds_)
        {
            if (!p.revents)
            {
                continue;
            }

            PollEvent e;
            e.fd = p.fd;
            e.error = (p.revents & (POLLERR | POLLHUP | POLLNVAL)) != 0;
            e.readable = (p.revents & POLLIN) != 0;
            e.writable = (p.revents & POLLOUT) != 0;
            out.push_back(e);
            p.revents = 0;
        }
        return out;
    }

}
