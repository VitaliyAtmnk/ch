#include "server/game_worker.hpp"

#include <cctype>

#include <spdlog/spdlog.h>

namespace server
{

    static std::string to_lower(std::string s)
    {
        for (auto &ch : s)
            ch = char(std::tolower((unsigned char)ch));
        return s;
    }

    GameWorker::GameWorker(int game_id,
                           std::string white_token,
                           std::string black_token,
                           EmitFn emit,
                           std::shared_ptr<spdlog::logger> log)
        : game_(game_id), emit_(std::move(emit)), log_(std::move(log))
    {
        game_.set_players(std::move(white_token), std::move(black_token));
    }

    GameWorker::~GameWorker()
    {
        stop();
        if (th_.joinable())
            th_.join();
    }

    void GameWorker::start()
    {
        if (log_)
            log_->info("game {} worker start", game_.id());
        th_ = std::thread([this] { run(); });
    }

    void GameWorker::stop()
    {
        {
            std::lock_guard<std::mutex> lk(m_);
            if (stopping_)
                return;
            stopping_ = true;
            Cmd c;
            c.kind = CmdKind::Stop;
            q_.push_back(std::move(c));
        }
        cv_.notify_one();
    }

    void GameWorker::post_move(int mover_fd,
                               std::string mover_token,
                               std::string from,
                               std::string to,
                               std::string promo)
    {
        {
            std::lock_guard<std::mutex> lk(m_);
            if (stopping_)
                return;
            Cmd c;
            c.kind = CmdKind::Move;
            c.mover_fd = mover_fd;
            c.mover_token = std::move(mover_token);
            c.from = std::move(from);
            c.to = std::move(to);
            c.promo = std::move(promo);
            q_.push_back(std::move(c));
        }
        cv_.notify_one();
    }

    void GameWorker::run()
    {
        while (true)
        {
            Cmd cmd;
            {
                std::unique_lock<std::mutex> lk(m_);
                cv_.wait(lk, [&] { return !q_.empty(); });
                cmd = std::move(q_.front());
                q_.pop_front();
            }

            if (cmd.kind == CmdKind::Stop)
            {
                if (log_)
                    log_->info("game {} worker stop", game_.id());
                return;
            }

            // Apply move
            const int gid = game_.id();
            if (log_)
                log_->debug("game {} move from token={} fd={} {}->{} promo={}",
                            gid,
                            cmd.mover_token,
                            cmd.mover_fd,
                            cmd.from,
                            cmd.to,
                            cmd.promo.empty() ? "-" : cmd.promo);
            auto res = game_.apply_move(cmd.mover_token, cmd.from, cmd.to, cmd.promo);
            if (!res.ok)
            {
                if (log_)
                    log_->warn("game {} illegal move token={} reason={}", gid, cmd.mover_token, res.reason);
                // Always respond with move-ack
                Outgoing ack;
                ack.kind = Outgoing::Kind::SendToFd;
                ack.fd = cmd.mover_fd;
                ack.line = "/move-ack|" + std::to_string(gid) + "|err|" + res.reason;
                emit_(std::move(ack));

                // Strike policy copied from Server::cmd_move
                Outgoing s;
                s.kind = (res.reason == "bad_coord") ? Outgoing::Kind::StrikeProtocol : Outgoing::Kind::StrikeGame;
                s.token = cmd.mover_token;
                emit_(std::move(s));
                continue;
            }

            Outgoing ok;
            ok.kind = Outgoing::Kind::SendToFd;
            ok.fd = cmd.mover_fd;
            ok.line = "/move-ack|" + std::to_string(gid) + "|ok";
            emit_(std::move(ok));

            // Broadcast moved
            std::string moved = "/moved|" + std::to_string(gid) + "|" + cmd.from + "|" + cmd.to;
            if (!cmd.promo.empty())
                moved += "|" + to_lower(cmd.promo);

            Outgoing o1;
            o1.kind = Outgoing::Kind::SendToToken;
            o1.token = game_.white_token();
            o1.line = moved;
            emit_(o1);

            Outgoing o2;
            o2.kind = Outgoing::Kind::SendToToken;
            o2.token = game_.black_token();
            o2.line = moved;
            emit_(o2);

            // Broadcast state
            std::string st = "/state|" + std::to_string(gid) + "|" + game_.fen() + "|turn|" +
                             std::string((game_.turn() == chess::Color::White) ? "white" : "black");

            Outgoing o3;
            o3.kind = Outgoing::Kind::SendToToken;
            o3.token = game_.white_token();
            o3.line = st;
            emit_(o3);

            Outgoing o4;
            o4.kind = Outgoing::Kind::SendToToken;
            o4.token = game_.black_token();
            o4.line = st;
            emit_(o4);

            // Checkmate/stalemate
            auto end = game_.evaluate_end();
            if (end.type == domain::GameEndType::Win)
            {
                if (log_)
                    log_->info("game {} end win reason={} winner={}", gid, end.reason, (end.winner == domain::Color::White) ? "white" : "black");
                std::string winner_token = (end.winner == domain::Color::White) ? game_.white_token() : game_.black_token();
                Outgoing e;
                e.kind = Outgoing::Kind::EndWin;
                e.game_id = gid;
                e.winner_token = std::move(winner_token);
                e.reason = end.reason;
                emit_(std::move(e));
                return;
            }
            if (end.type == domain::GameEndType::Draw)
            {
                if (log_)
                    log_->info("game {} end draw reason={}", gid, end.reason);
                Outgoing e;
                e.kind = Outgoing::Kind::EndDraw;
                e.game_id = gid;
                e.reason = end.reason;
                emit_(std::move(e));
                return;
            }
        }
    }

} // namespace server
