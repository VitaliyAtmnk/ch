#include "domain/game.hpp"

namespace domain
{

    Game::Game(int id) : id_(id) {}

    void Game::set_players(const std::string &white_token, const std::string &black_token)
    {
        white_token_ = white_token;
        black_token_ = black_token;
    }

    chess::MoveResult Game::apply_move(const std::string &mover_token,
                                       const std::string &from,
                                       const std::string &to,
                                       const std::string &promo)
    {
        chess::Color mover_color;
        if (mover_token == white_token_)
            mover_color = chess::Color::White;
        else if (mover_token == black_token_)
            mover_color = chess::Color::Black;
        else
            return {false, "illegal_move"};

        return board_.make_move(mover_color, from, to, promo);
    }

    GameEnd Game::evaluate_end() const
    {
        // side to move after the move is board_.turn()
        chess::Color side = board_.turn();
        bool has_move = board_.has_any_legal_move(side);
        bool check = board_.in_check(side);

        if (has_move)
            return {};

        if (check)
        {
            // checkmate: previous mover wins
            GameEnd ge;
            ge.type = GameEndType::Win;
            ge.reason = "checkmate";
            ge.winner = (side == chess::Color::White) ? Color::Black : Color::White;
            return ge;
        }
        else
        {
            GameEnd ge;
            ge.type = GameEndType::Draw;
            ge.reason = "stalemate";
            return ge;
        }
    }

}