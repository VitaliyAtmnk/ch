#include "chess/board.hpp"
#include <cctype>
#include <sstream>
#include <vector>

namespace chess
{

    static int dir(Color c) { return (c == Color::White) ? +1 : -1; }

    Board::Board()
    {
        for (auto &r : board_)
            r.fill('.');
        // Pieces: white bottom (rank 1), black top (rank 8)
        const std::string back_w = "RNBQKBNR";
        const std::string back_b = "rnbqkbnr";
        for (int f = 0; f < 8; ++f)
        {
            board_[0][f] = back_w[f];
            board_[1][f] = 'P';
            board_[6][f] = 'p';
            board_[7][f] = back_b[f];
        }
    }

    bool Board::is_white(char p) { return std::isupper((unsigned char)p) && p != '.'; }
    bool Board::is_black(char p) { return std::islower((unsigned char)p) && p != '.'; }
    bool Board::is_empty(char p) { return p == '.'; }

    Color Board::piece_color(char p) { return is_white(p) ? Color::White : Color::Black; }

    char Board::promo_piece(Color mover, char promo)
    {
        promo = (char)std::tolower((unsigned char)promo);
        char p = 'q';
        if (promo == 'q' || promo == 'r' || promo == 'b' || promo == 'n')
            p = promo;
        if (mover == Color::White)
            return (char)std::toupper((unsigned char)p);
        return p;
    }

    bool Board::parse_square(const std::string &s, Square &out)
    {
        if (s.size() != 2)
            return false;
        char f = s[0];
        char r = s[1];
        if (f >= 'A' && f <= 'H')
            f = char(f - 'A' + 'a');
        if (f < 'a' || f > 'h')
            return false;
        if (r < '1' || r > '8')
            return false;
        out.file = f - 'a';
        out.rank = r - '1';
        return true;
    }

    Square Board::find_king(Color side) const
    {
        char k = (side == Color::White) ? 'K' : 'k';
        for (int r = 0; r < 8; ++r)
            for (int f = 0; f < 8; ++f)
                if (board_[r][f] == k)
                    return {f, r};
        return {-1, -1};
    }

    bool Board::path_clear(Square a, Square b) const
    {
        int df = (b.file > a.file) ? 1 : (b.file < a.file) ? -1
                                                           : 0;
        int dr = (b.rank > a.rank) ? 1 : (b.rank < a.rank) ? -1
                                                           : 0;
        int f = a.file + df;
        int r = a.rank + dr;
        while (f != b.file || r != b.rank)
        {
            if (!is_empty(board_[r][f]))
                return false;
            f += df;
            r += dr;
        }
        return true;
    }

    bool Board::square_attacked(int file, int rank, Color by) const
    {
        // Pawns
        int pawn_dir = (by == Color::White) ? +1 : -1;
        int pr = rank - pawn_dir;
        if (pr >= 0 && pr < 8)
        {
            for (int df : {-1, +1})
            {
                int pf = file + df;
                if (pf < 0 || pf >= 8)
                    continue;
                char p = board_[pr][pf];
                if (by == Color::White && p == 'P')
                    return true;
                if (by == Color::Black && p == 'p')
                    return true;
            }
        }

        // Knights
        static const int kdx[8] = {1, 2, 2, 1, -1, -2, -2, -1};
        static const int kdy[8] = {2, 1, -1, -2, -2, -1, 1, 2};
        for (int i = 0; i < 8; ++i)
        {
            int f = file + kdx[i];
            int r = rank + kdy[i];
            if (f < 0 || f >= 8 || r < 0 || r >= 8)
                continue;
            char p = board_[r][f];
            if (by == Color::White && p == 'N')
                return true;
            if (by == Color::Black && p == 'n')
                return true;
        }

        // King adjacency
        for (int dr = -1; dr <= 1; ++dr)
            for (int df = -1; df <= 1; ++df)
            {
                if (dr == 0 && df == 0)
                    continue;
                int f = file + df, r = rank + dr;
                if (f < 0 || f >= 8 || r < 0 || r >= 8)
                    continue;
                char p = board_[r][f];
                if (by == Color::White && p == 'K')
                    return true;
                if (by == Color::Black && p == 'k')
                    return true;
            }

        // Sliding pieces: rook/queen (orthogonal)
        auto scan = [&](int df, int dr, char w1, char w2, char b1, char b2)
        {
            int f = file + df, r = rank + dr;
            while (f >= 0 && f < 8 && r >= 0 && r < 8)
            {
                char p = board_[r][f];
                if (!is_empty(p))
                {
                    if (by == Color::White && (p == w1 || p == w2))
                        return true;
                    if (by == Color::Black && (p == b1 || p == b2))
                        return true;
                    return false;
                }
                f += df;
                r += dr;
            }
            return false;
        };

        if (scan(1, 0, 'R', 'Q', 'r', 'q'))
            return true;
        if (scan(-1, 0, 'R', 'Q', 'r', 'q'))
            return true;
        if (scan(0, 1, 'R', 'Q', 'r', 'q'))
            return true;
        if (scan(0, -1, 'R', 'Q', 'r', 'q'))
            return true;

        // bishop/queen (diagonal)
        if (scan(1, 1, 'B', 'Q', 'b', 'q'))
            return true;
        if (scan(-1, 1, 'B', 'Q', 'b', 'q'))
            return true;
        if (scan(1, -1, 'B', 'Q', 'b', 'q'))
            return true;
        if (scan(-1, -1, 'B', 'Q', 'b', 'q'))
            return true;

        return false;
    }

    bool Board::in_check(Color side) const
    {
        Square k = find_king(side);
        if (k.file < 0)
            return false;
        Color attacker = (side == Color::White) ? Color::Black : Color::White;
        return square_attacked(k.file, k.rank, attacker);
    }

    bool Board::is_castle_move(char piece, Square a, Square b) const
    {
        if (piece != 'K' && piece != 'k')
            return false;
        if (a.rank != b.rank)
            return false;
        // e1->g1, e1->c1, e8->g8, e8->c8
        if (a.file != 4)
            return false;
        if (b.file == 6 || b.file == 2)
            return true;
        return false;
    }

    MoveResult Board::validate_castle(Color mover, Square a, Square b) const
    {
        // must not be in check, squares passed must not be attacked
        if (in_check(mover))
            return {false, "illegal_move"};

        if (mover == Color::White)
        {
            if (a.rank != 0 || a.file != 4)
                return {false, "illegal_move"};
            if (b.file == 6)
            {
                if (!w_k_)
                    return {false, "illegal_move"};
                if (!is_empty(board_[0][5]) || !is_empty(board_[0][6]))
                    return {false, "illegal_move"};
                if (board_[0][7] != 'R')
                    return {false, "illegal_move"};
                if (square_attacked(5, 0, Color::Black) || square_attacked(6, 0, Color::Black))
                    return {false, "illegal_move"};
                return {true, ""};
            }
            if (b.file == 2)
            {
                if (!w_q_)
                    return {false, "illegal_move"};
                if (!is_empty(board_[0][1]) || !is_empty(board_[0][2]) || !is_empty(board_[0][3]))
                    return {false, "illegal_move"};
                if (board_[0][0] != 'R')
                    return {false, "illegal_move"};
                if (square_attacked(3, 0, Color::Black) || square_attacked(2, 0, Color::Black))
                    return {false, "illegal_move"};
                return {true, ""};
            }
        }
        else
        {
            if (a.rank != 7 || a.file != 4)
                return {false, "illegal_move"};
            if (b.file == 6)
            {
                if (!b_k_)
                    return {false, "illegal_move"};
                if (!is_empty(board_[7][5]) || !is_empty(board_[7][6]))
                    return {false, "illegal_move"};
                if (board_[7][7] != 'r')
                    return {false, "illegal_move"};
                if (square_attacked(5, 7, Color::White) || square_attacked(6, 7, Color::White))
                    return {false, "illegal_move"};
                return {true, ""};
            }
            if (b.file == 2)
            {
                if (!b_q_)
                    return {false, "illegal_move"};
                if (!is_empty(board_[7][1]) || !is_empty(board_[7][2]) || !is_empty(board_[7][3]))
                    return {false, "illegal_move"};
                if (board_[7][0] != 'r')
                    return {false, "illegal_move"};
                if (square_attacked(3, 7, Color::White) || square_attacked(2, 7, Color::White))
                    return {false, "illegal_move"};
                return {true, ""};
            }
        }
        return {false, "illegal_move"};
    }

    Board Board::apply_castle(Color mover, Square a, Square b) const
    {
        Board nb = *this;
        // Move king
        nb.board_[b.rank][b.file] = nb.board_[a.rank][a.file];
        nb.board_[a.rank][a.file] = '.';

        // Move rook
        if (mover == Color::White)
        {
            nb.w_k_ = nb.w_q_ = false;
            if (b.file == 6)
            { // king side
                nb.board_[0][5] = 'R';
                nb.board_[0][7] = '.';
            }
            else
            { // queen side
                nb.board_[0][3] = 'R';
                nb.board_[0][0] = '.';
            }
        }
        else
        {
            nb.b_k_ = nb.b_q_ = false;
            if (b.file == 6)
            {
                nb.board_[7][5] = 'r';
                nb.board_[7][7] = '.';
            }
            else
            {
                nb.board_[7][3] = 'r';
                nb.board_[7][0] = '.';
            }
        }

        nb.ep_file_ = nb.ep_rank_ = -1;
        nb.halfmove_++;
        if (nb.turn_ == Color::Black)
            nb.fullmove_++;
        nb.turn_ = (nb.turn_ == Color::White) ? Color::Black : Color::White;
        return nb;
    }

    bool Board::is_enpassant(Color mover, char piece, Square a, Square b) const
    {
        if (piece != 'P' && piece != 'p')
            return false;
        if (b.file != ep_file_ || b.rank != ep_rank_)
            return false;
        if (!is_empty(board_[b.rank][b.file]))
            return false;
        int d = dir(mover);
        if (b.rank - a.rank != d)
            return false;
        if (std::abs(b.file - a.file) != 1)
            return false;
        return true;
    }

    MoveResult Board::validate_basic(Color mover, Square a, Square b, char promo) const
    {
        if (a.file < 0 || b.file < 0)
            return {false, "bad_coord"};

        char piece = board_[a.rank][a.file];
        if (is_empty(piece))
            return {false, "illegal_move"};
        if (piece_color(piece) != mover)
            return {false, "illegal_move"};

        char target = board_[b.rank][b.file];
        if (!is_empty(target) && piece_color(target) == mover)
            return {false, "illegal_move"};

        int df = b.file - a.file;
        int dr = b.rank - a.rank;

        // Castling
        if (is_castle_move(piece, a, b))
        {
            auto r = validate_castle(mover, a, b);
            if (!r.ok)
                return r;
            // check after move (king safety is covered by validate_castle squares attacked)
            return {true, ""};
        }

        // Pawn
        if (piece == 'P' || piece == 'p')
        {
            int d = dir(mover);
            bool is_capture = (std::abs(df) == 1 && dr == d);

            // promotion requirement
            bool promotes = (mover == Color::White && b.rank == 7) || (mover == Color::Black && b.rank == 0);
            if (promotes && promo == 0)
                return {false, "need_promotion"};
            if (!promotes && promo != 0)
                return {false, "bad_promotion"};

            if (df == 0)
            {
                if (!is_empty(target))
                    return {false, "illegal_move"};
                if (dr == d)
                    return {true, ""};

                // two-step from start
                int start_rank = (mover == Color::White) ? 1 : 6;
                if (a.rank == start_rank && dr == 2 * d)
                {
                    int mid_rank = a.rank + d;
                    if (!is_empty(board_[mid_rank][a.file]))
                        return {false, "illegal_move"};
                    return {true, ""};
                }
                return {false, "illegal_move"};
            }
            else if (is_capture)
            {
                // normal capture
                if (!is_empty(target))
                    return {true, ""};

                // en passant
                if (is_enpassant(mover, piece, a, b))
                    return {true, ""};

                return {false, "illegal_move"};
            }
            return {false, "illegal_move"};
        }

        // Knight
        if (piece == 'N' || piece == 'n')
        {
            int adf = std::abs(df), adr = std::abs(dr);
            if ((adf == 1 && adr == 2) || (adf == 2 && adr == 1))
                return {true, ""};
            return {false, "illegal_move"};
        }

        // King (non-castle)
        if (piece == 'K' || piece == 'k')
        {
            if (std::abs(df) <= 1 && std::abs(dr) <= 1)
                return {true, ""};
            return {false, "illegal_move"};
        }

        // Bishop / Rook / Queen
        bool diag = (std::abs(df) == std::abs(dr) && df != 0);
        bool ortho = ((df == 0) != (dr == 0)) && !(df == 0 && dr == 0);

        if (piece == 'B' || piece == 'b')
        {
            if (!diag)
                return {false, "illegal_move"};
            if (!path_clear(a, b))
                return {false, "illegal_move"};
            return {true, ""};
        }
        if (piece == 'R' || piece == 'r')
        {
            if (!ortho)
                return {false, "illegal_move"};
            if (!path_clear(a, b))
                return {false, "illegal_move"};
            return {true, ""};
        }
        if (piece == 'Q' || piece == 'q')
        {
            if (!(diag || ortho))
                return {false, "illegal_move"};
            if (!path_clear(a, b))
                return {false, "illegal_move"};
            return {true, ""};
        }

        return {false, "illegal_move"};
    }

    Board Board::after_move(Square a, Square b, char promo) const
    {
        Board nb = *this;

        char piece = nb.board_[a.rank][a.file];
        char target = nb.board_[b.rank][b.file];
        Color mover = piece_color(piece);

        // update castling rights if king/rook moves or rook captured
        auto revoke_rook_rights_if_needed = [&](Square sq, char captured_piece)
        {
            if (captured_piece == 'R')
            {
                if (sq.rank == 0 && sq.file == 0)
                    nb.w_q_ = false;
                if (sq.rank == 0 && sq.file == 7)
                    nb.w_k_ = false;
            }
            if (captured_piece == 'r')
            {
                if (sq.rank == 7 && sq.file == 0)
                    nb.b_q_ = false;
                if (sq.rank == 7 && sq.file == 7)
                    nb.b_k_ = false;
            }
        };

        // castling special apply
        if (is_castle_move(piece, a, b))
        {
            return apply_castle(mover, a, b);
        }

        // en passant capture
        if (is_enpassant(mover, piece, a, b))
        {
            // captured pawn is behind target
            int cap_rank = b.rank - dir(mover);
            nb.board_[cap_rank][b.file] = '.';
            target = 'p'; // for halfmove clock reset semantics
        }

        // move piece
        nb.board_[b.rank][b.file] = piece;
        nb.board_[a.rank][a.file] = '.';

        // promotion
        if ((piece == 'P' && b.rank == 7) || (piece == 'p' && b.rank == 0))
        {
            nb.board_[b.rank][b.file] = promo_piece(mover, promo);
        }

        // revoke castling on king move
        if (piece == 'K')
            nb.w_k_ = nb.w_q_ = false;
        if (piece == 'k')
            nb.b_k_ = nb.b_q_ = false;

        // revoke castling on rook move
        if (piece == 'R')
        {
            if (a.rank == 0 && a.file == 0)
                nb.w_q_ = false;
            if (a.rank == 0 && a.file == 7)
                nb.w_k_ = false;
        }
        if (piece == 'r')
        {
            if (a.rank == 7 && a.file == 0)
                nb.b_q_ = false;
            if (a.rank == 7 && a.file == 7)
                nb.b_k_ = false;
        }

        // revoke castling if rook captured
        if (!is_empty(target))
            revoke_rook_rights_if_needed(b, target);

        // set en passant target after double pawn push
        nb.ep_file_ = nb.ep_rank_ = -1;
        if (piece == 'P' || piece == 'p')
        {
            int d = dir(mover);
            if (b.file == a.file && b.rank - a.rank == 2 * d)
            {
                nb.ep_file_ = a.file;
                nb.ep_rank_ = a.rank + d;
            }
        }

        // halfmove clock reset on pawn move or capture
        if (piece == 'P' || piece == 'p' || !is_empty(target))
            nb.halfmove_ = 0;
        else
            nb.halfmove_++;

        // fullmove increments after black move
        if (nb.turn_ == Color::Black)
            nb.fullmove_++;

        nb.turn_ = (nb.turn_ == Color::White) ? Color::Black : Color::White;
        return nb;
    }

    MoveResult Board::make_move(Color mover_color, const std::string &from, const std::string &to, const std::string &promo_s)
    {
        if (mover_color != turn_)
            return {false, "not_your_turn"};

        Square a, b;
        if (!parse_square(from, a) || !parse_square(to, b))
            return {false, "bad_coord"};

        char promo = 0;
        if (!promo_s.empty())
        {
            if (promo_s.size() != 1)
                return {false, "bad_promotion"};
            promo = promo_s[0];
            promo = (char)std::tolower((unsigned char)promo);
            if (!(promo == 'q' || promo == 'r' || promo == 'b' || promo == 'n'))
                return {false, "bad_promotion"};
        }

        auto basic = validate_basic(mover_color, a, b, promo);
        if (!basic.ok)
            return basic;

        // apply and verify king safety
        Board nb;
        if (is_castle_move(board_[a.rank][a.file], a, b))
        {
            nb = apply_castle(mover_color, a, b);
        }
        else
        {
            nb = after_move(a, b, promo);
        }

        if (nb.in_check(mover_color))
            return {false, "illegal_move"};
        *this = nb;
        return {true, ""};
    }

    bool Board::has_any_legal_move(Color side) const
    {
        // brute-force: try all from/to squares with possible promotions
        // OK for a simple server.
        for (int r1 = 0; r1 < 8; ++r1)
            for (int f1 = 0; f1 < 8; ++f1)
            {
                char p = board_[r1][f1];
                if (is_empty(p))
                    continue;
                if (piece_color(p) != side)
                    continue;

                for (int r2 = 0; r2 < 8; ++r2)
                    for (int f2 = 0; f2 < 8; ++f2)
                    {
                        if (r1 == r2 && f1 == f2)
                            continue;

                        Square a{f1, r1}, b{f2, r2};
                        // try without promo
                        auto basic = validate_basic(side, a, b, 0);
                        if (basic.ok)
                        {
                            Board nb = is_castle_move(p, a, b) ? apply_castle(side, a, b) : after_move(a, b, 0);
                            if (!nb.in_check(side))
                                return true;
                        }

                        // try promotions if pawn reaches last rank
                        if (p == 'P' && r2 == 7)
                        {
                            for (char pr : {'q', 'r', 'b', 'n'})
                            {
                                auto bx = validate_basic(side, a, b, pr);
                                if (bx.ok)
                                {
                                    Board nb = after_move(a, b, pr);
                                    if (!nb.in_check(side))
                                        return true;
                                }
                            }
                        }
                        if (p == 'p' && r2 == 0)
                        {
                            for (char pr : {'q', 'r', 'b', 'n'})
                            {
                                auto bx = validate_basic(side, a, b, pr);
                                if (bx.ok)
                                {
                                    Board nb = after_move(a, b, pr);
                                    if (!nb.in_check(side))
                                        return true;
                                }
                            }
                        }
                    }
            }
        return false;
    }

    std::string Board::to_fen() const
    {
        // Minimal FEN (piece placement + side + castling + ep + halfmove + fullmove)
        std::ostringstream oss;

        for (int r = 7; r >= 0; --r)
        {
            int empty = 0;
            for (int f = 0; f < 8; ++f)
            {
                char p = board_[r][f];
                if (p == '.')
                {
                    empty++;
                    continue;
                }
                if (empty)
                {
                    oss << empty;
                    empty = 0;
                }
                oss << p;
            }
            if (empty)
                oss << empty;
            if (r)
                oss << '/';
        }

        oss << ' ' << ((turn_ == Color::White) ? 'w' : 'b') << ' ';

        std::string cast;
        if (w_k_)
            cast += 'K';
        if (w_q_)
            cast += 'Q';
        if (b_k_)
            cast += 'k';
        if (b_q_)
            cast += 'q';
        if (cast.empty())
            cast = "-";
        oss << cast << ' ';

        if (ep_file_ < 0)
            oss << "-";
        else
        {
            char f = char('a' + ep_file_);
            char r = char('1' + ep_rank_);
            oss << f << r;
        }

        oss << ' ' << halfmove_ << ' ' << fullmove_;
        return oss.str();
    }

}