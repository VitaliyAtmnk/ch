#pragma once
#include <string>
#include <vector>
#include <cstddef>

namespace protocol
{

    // Collects bytes and returns complete lines (without '\n', may keep '\r' to be trimmed by parser).
    class LineFramer
    {
    public:
        LineFramer(std::size_t max_line, std::size_t max_buffer);

        // feed raw bytes
        void feed(const char *data, std::size_t n);

        // extract all complete lines
        std::vector<std::string> pop_lines();

        // if buffer grows too large without newline -> caller may close connection
        bool buffer_overflow() const noexcept { return overflow_; }

        void reset_overflow() noexcept { overflow_ = false; }

    private:
        std::size_t max_line_;
        std::size_t max_buffer_;
        std::string buf_;
        bool overflow_ = false;
    };

}
