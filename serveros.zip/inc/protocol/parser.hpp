#pragma once
#include <string>
#include <optional>
#include "protocol/message.hpp"

namespace protocol
{

    // Parses a single line into Message.
    // Expected: "/cmd|arg1|arg2"
    class Parser
    {
    public:
        static std::optional<Message> parse_line(const std::string &line, std::string &out_error_details);

    private:
        static std::string to_lower(std::string s);
    };

}
