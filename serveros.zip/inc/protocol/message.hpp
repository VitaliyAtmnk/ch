#pragma once
#include <string>
#include <vector>

namespace protocol
{

    struct Message
    {
        std::string cmd;               // lower-case command name (without leading '/')
        std::vector<std::string> args; // pipe-separated args
    };

}
