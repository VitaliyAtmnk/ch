#pragma once
#include <string>

namespace err
{

    enum class Code
    {
        BadFormat,
        UnknownCommand,
        IllegalInState,
        TooLong,
        Unauthorized,
        NickInvalid,
        NickAlreadySet,
        NickInUse,
        ReconnectFailed,
        NotInQueue,
        AlreadyInQueue,
        NotInGame,
        BadGameId,
        Internal
    };

    inline const char *to_string(Code c)
    {
        switch (c)
        {
        case Code::BadFormat:
            return "bad_format";
        case Code::UnknownCommand:
            return "unknown_cmd";
        case Code::IllegalInState:
            return "illegal_in_state";
        case Code::TooLong:
            return "too_long";
        case Code::Unauthorized:
            return "unauthorized";
        case Code::NickInvalid:
            return "nick_invalid";
        case Code::NickAlreadySet:
            return "nick_already_set";
        case Code::NickInUse:
            return "nick_in_use";
        case Code::ReconnectFailed:
            return "reconnect_failed";
        case Code::NotInQueue:
            return "not_in_queue";
        case Code::AlreadyInQueue:
            return "already_in_queue";
        case Code::NotInGame:
            return "not_in_game";
        case Code::BadGameId:
            return "bad_gameid";
        case Code::Internal:
            return "internal";
        }
        return "internal";
    }

    inline std::string line(Code c, const std::string &details = "")
    {
        if (details.empty())
        {
            return std::string("/err|") + to_string(c) + "|";
        }

        return std::string("/err|") + to_string(c) + "|" + details;
    }

}
