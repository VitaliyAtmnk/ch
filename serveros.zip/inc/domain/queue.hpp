#pragma once
#include <deque>
#include <string>
#include <unordered_set>

namespace domain
{

    // Minimal FIFO matchmaking queue.
    class MatchQueue
    {
    public:
        void enqueue(const std::string &token)
        {
            if (in_.count(token))
            {
                return;
            }

            q_.push_back(token);
            in_.insert(token);
        }

        void remove(const std::string &token)
        {
            if (!in_.count(token))
            {
                return;
            }

            in_.erase(token);

            // lazy removal from deque; cleaned during pop2
        }

        template <typename IsValid>
        bool pop_two(std::string &a, std::string &b, IsValid is_valid)
        {
            a.clear();
            b.clear();

            cleanup_front(is_valid);
            if (q_.empty())
                return false;

            // vezmeme prvního (dočasně)
            a = q_.front();
            q_.pop_front();
            in_.erase(a);

            cleanup_front(is_valid);
            if (q_.empty())
            {
                // druhý není -> vrať prvního zpět do fronty (rollback)
                q_.push_front(a);
                in_.insert(a);
                a.clear();
                return false;
            }

            b = q_.front();
            q_.pop_front();
            in_.erase(b);
            return true;
        }

    private:
        std::deque<std::string> q_;
        std::unordered_set<std::string> in_;

        template <typename IsValid>
        void cleanup_front(IsValid is_valid)
        {
            while (!q_.empty())
            {
                const auto &t = q_.front();
                if (!in_.count(t))
                {
                    q_.pop_front();
                    continue;
                } // was removed

                if (!is_valid(t))
                {
                    q_.pop_front();
                    in_.erase(t);
                    continue;
                }

                break;
            }
        }
    };

}
