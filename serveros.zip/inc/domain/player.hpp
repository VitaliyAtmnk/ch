#pragma once
#include <string>

namespace domain
{

    enum class ConnState
    {
        Connected,
        Lobby,
        Queue,
        Game
    };
    
    enum class Color
    {
        None,
        White,
        Black
    };

    inline const char *color_str(Color c)
    {
        switch (c)
        {
        case Color::White:
            return "white";
        case Color::Black:
            return "black";
        default:
            return "none";
        }
    }

    struct PlayerSession
    {
        std::string token;
        std::string nickname;

        int fd = -1; // online fd or -1
        ConnState state = ConnState::Connected;

        int protocol_strikes = 0;
        int game_strikes = 0;

        int game_id = -1;
        Color color = Color::None;
    };

}