#pragma once
#include <string>
#include "domain/player.hpp"
#include "chess/board.hpp"

namespace domain
{

    enum class GameEndType
    {
        None,
        Win,
        Lose,
        Draw
    };

    struct GameEnd
    {
        GameEndType type = GameEndType::None;
        std::string reason;         // "checkmate", "stalemate", "opponent_disconnected", ...
        Color winner = Color::None; // for Win/Lose
    };

    class Game
    {
    public:
        explicit Game(int id);

        int id() const noexcept { return id_; }

        void set_players(const std::string &white_token, const std::string &black_token);

        const std::string &white_token() const noexcept { return white_token_; }
        const std::string &black_token() const noexcept { return black_token_; }

        chess::Color turn() const noexcept { return board_.turn(); }
        std::string fen() const { return board_.to_fen(); }

        // Validate+apply move; returns {ok, reason} as chess::MoveResult
        chess::MoveResult apply_move(const std::string &mover_token,
                                     const std::string &from,
                                     const std::string &to,
                                     const std::string &promo);

        // After a successful move, evaluate if game ended (checkmate/stalemate).
        GameEnd evaluate_end() const;

    private:
        int id_;
        std::string white_token_;
        std::string black_token_;
        chess::Board board_;
    };

} // namespace domain
