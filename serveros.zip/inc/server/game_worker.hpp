#pragma once

#include <condition_variable>
#include <deque>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <thread>

#include "domain/game.hpp"

namespace spdlog { class logger; }

namespace server
{

    // Messages produced by a game thread and consumed by the main server thread.
    struct Outgoing
    {
        enum class Kind
        {
            SendToFd,
            SendToToken,
            StrikeProtocol,
            StrikeGame,
            EndWin,
            EndDraw,
        };

        Kind kind = Kind::SendToFd;

        // For SendToFd
        int fd = -1;

        // For SendToToken / Strike* (token identifies the player session)
        std::string token;

        // For Send*
        std::string line;

        // For End*
        int game_id = -1;
        std::string winner_token; // EndWin
        std::string reason;       // EndWin/EndDraw
    };

    // One worker thread per active game. It owns the chess logic for that game.
    // Networking, sessions, queue etc. stay in the main server thread.
    class GameWorker
    {
    public:
        using EmitFn = std::function<void(Outgoing)>;

        GameWorker(int game_id,
                   std::string white_token,
                   std::string black_token,
                   EmitFn emit,
                   std::shared_ptr<spdlog::logger> log = {});
        ~GameWorker();

        GameWorker(const GameWorker &) = delete;
        GameWorker &operator=(const GameWorker &) = delete;

        void start();
        void stop();

        // Enqueue a move; the worker will validate/apply it and emit protocol lines.
        void post_move(int mover_fd,
                       std::string mover_token,
                       std::string from,
                       std::string to,
                       std::string promo);

    private:
        enum class CmdKind
        {
            Move,
            Stop
        };

        struct Cmd
        {
            CmdKind kind = CmdKind::Move;
            int mover_fd = -1;
            std::string mover_token;
            std::string from;
            std::string to;
            std::string promo;
        };

        void run();

        std::mutex m_;
        std::condition_variable cv_;
        std::deque<Cmd> q_;
        bool stopping_ = false;

        std::thread th_;

        domain::Game game_;
        EmitFn emit_;

        std::shared_ptr<spdlog::logger> log_;
    };

} // namespace server
