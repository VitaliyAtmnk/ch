#pragma once
#include <chrono>
#include <cstdint>
#include <functional>
#include <memory>
#include <random>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <deque>
#include <mutex>

// Forward declare spdlog to avoid pulling in the full header here.
namespace spdlog { class logger; }

#include "config.hpp"
#include "errors.hpp"

#include "net/tcp_listener.hpp"
#include "net/connection.hpp"
#include "net/poller.hpp"

#include "protocol/parser.hpp"

#include "domain/player.hpp"
#include "domain/queue.hpp"
#include "domain/game.hpp"

#include "server/game_worker.hpp"

namespace server
{

    class Server
    {
    public:
        explicit Server(cfg::Config cfg);

        int start(); // blocking run loop

    private:
        enum class CloseCause
        {
            Disconnected,
            Kicked,
            ClientExit
        };

        cfg::Config cfg_;
        net::TcpListener listener_;
        net::Poller poller_;
        std::mt19937 rng_{std::random_device{}()};

        using Clock = std::chrono::steady_clock;

        struct KeepAliveState
        {
            Clock::time_point last_activity{};
            bool awaiting_pong = false;
            std::uint64_t nonce = 0;
            Clock::time_point ping_sent_at{};
        };

        std::unordered_map<int, KeepAliveState> keepalive_;
        std::uint64_t keepalive_nonce_ = 1;

        // connections by fd
        std::unordered_map<int, std::unique_ptr<net::Connection>> conns_;

        // fd -> peer string (ip:port)
        std::unordered_map<int, std::string> peers_;

        // fd -> token (fast lookup for logs + session_for_fd)
        std::unordered_map<int, std::string> fd_to_token_;

        // Logger (thread-safe)
        std::shared_ptr<spdlog::logger> log_;

        // Wake-up pipe to break out of poll() when worker threads enqueue outgoing events.
        int wake_r_ = -1;
        int wake_w_ = -1;

        // sessions by token
        std::unordered_map<std::string, domain::PlayerSession> sessions_;

        struct GameMeta
        {
            std::string white_token;
            std::string black_token;
        };

        // Lightweight metadata about active games (tokens); chess logic lives in GameWorker threads.
        std::unordered_map<int, GameMeta> games_;

        // One worker per game (thread-per-game).
        std::unordered_map<int, std::unique_ptr<GameWorker>> game_workers_;

        // Cross-thread queue from game workers -> main server thread.
        std::mutex out_mtx_;
        std::deque<Outgoing> out_q_;

        domain::MatchQueue queue_;
        std::unordered_set<std::string> names_in_use_;
        std::unordered_set<int> closing_fds_; // fds scheduled for graceful close after output is flushed

        // fd -> close cause; consumed in close_fd()
        std::unordered_map<int, CloseCause> close_causes_;

        int next_game_id_ = 1;

        using Handler = std::function<void(int fd, const protocol::Message &)>;
        std::unordered_map<std::string, Handler> handlers_;

    private:
        // lifecycle
        void create_commands();
        void accept_clients();
        void request_close_fd(int fd);
        void close_fd(int fd);
        void finalize_graceful_close(int fd);

        void enqueue_outgoing(Outgoing o);
        void drain_outgoing();

        void init_logger();
        void init_wakeup_pipe();
        void drain_wakeup_pipe();

        // IO
        void rebuild_pollset();
        void on_event(const net::PollEvent &e);

        // protocol
        void handle_line(int fd, const std::string &line);
        void dispatch(int fd, const protocol::Message &msg);
        void send_fd(int fd, const std::string &line);

        // session helpers
        std::string token_for_fd(int fd) const;
        domain::PlayerSession *session_for_fd(int fd);
        domain::PlayerSession *session_by_token(const std::string &token);

        std::string new_token();

        // strikes & kick
        void add_protocol_strike(domain::PlayerSession &s);
        void add_game_strike(domain::PlayerSession &s);
        
        // AFKing
        void ka_on_connected(int fd);
        void ka_on_disconnected(int fd);
        void ka_note_activity(int fd);
        void ka_note_pong(int fd, const std::string &nonce);
        void ka_tick();

        // /move response helpers (keeps responses consistent)
        void send_move_ack_ok(int fd, int game_id);
        void send_move_ack_err(int fd, int game_id, const std::string &reason);

        void protocol_strike(domain::PlayerSession *s, int fd, err::Code code, const std::string &details);
        void game_strike(domain::PlayerSession &s, int fd, int game_id, const std::string &reason);
        void kick(domain::PlayerSession &s, const std::string &reason);

        // matchmaking & game
        void try_matchmake();
        void start_game(const std::string &token_a, const std::string &token_b);

        void end_game_with_winner(int game_id, const std::string &winner_token, const std::string &reason);
        void end_game_draw(int game_id, const std::string &reason);
        void handle_disconnect_in_game(domain::PlayerSession &leaver, int game_id, CloseCause cause);

        // command handlers
        void cmd_hello(int fd, const protocol::Message &msg);
        void cmd_exit(int fd, const protocol::Message &msg);
 
        void cmd_ping(int fd, const protocol::Message &msg);
        void cmd_pong(int fd, const protocol::Message& msg);

        void cmd_nick(int fd, const protocol::Message &msg);
        void cmd_reconnect(int fd, const protocol::Message &msg);

        void cmd_queue(int fd, const protocol::Message &msg);
        void cmd_leave_queue(int fd, const protocol::Message &msg);

        void cmd_move(int fd, const protocol::Message &msg);
        void cmd_resign(int fd, const protocol::Message &msg);

        // validation
        static bool is_nick_ok(const std::string &s);

        void mark_close_cause(int fd, CloseCause cause);
        CloseCause consume_close_cause(int fd);
    };

}