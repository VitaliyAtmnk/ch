#pragma once
#include <cstddef>

namespace cfg
{

    struct Config
    {
        int port = 5555;
        int backlog = 64;
        int version = 1;

        // Protocol framing
        std::size_t max_line = 256;    // max bytes per line (excluding newline tolerance)
        std::size_t max_buffer = 2048; // max buffered bytes without '\n' before dropping

        // Strikes
        int protocol_strikes_max = 3;
        int game_strikes_max = 20;

        // Poll timeout (ms)
        int poll_timeout_ms = 1000;

        // Keep-alive (ms)
        int ping_interval_ms = 15000; // po jaké době neaktivity server pingne
        int pong_timeout_ms = 5000;   // jak dlouho čekat na pong po pingu
        int idle_drop_ms = 60000;
    };

}