#pragma once
#include <string>
#include <cstddef>
#include "protocol/framer.hpp"

namespace net {

class Connection {
public:
    explicit Connection(int fd, std::size_t max_line, std::size_t max_buffer);
    ~Connection();

    Connection(const Connection&) = delete;
    Connection& operator=(const Connection&) = delete;

    int fd() const noexcept { return fd_; }

    // Read available bytes into framer; returns false if peer closed or fatal error.
    bool read_into_framer();

    // Pop complete protocol lines
    std::vector<std::string> pop_lines() { return framer_.pop_lines(); }

    bool framer_overflow() const noexcept { return framer_.buffer_overflow(); }

    // Queue a line (without \n). Connection will append '\n' internally.
    void send_line(const std::string& line_no_nl);

    // Try flush output buffer; returns false if fatal error.
    bool flush();

    bool has_pending_output() const noexcept { return !outbuf_.empty(); }

private:
    int fd_ = -1;
    protocol::LineFramer framer_;
    std::string outbuf_;

    static bool set_nonblocking(int fd);
};

} // namespace net
