#pragma once
#include <vector>
#include <unordered_map>
#include <poll.h>

namespace net {

struct PollEvent {
    int fd = -1;
    bool readable = false;
    bool writable = false;
    bool error = false;
};

class Poller {
public:
    void clear();
    void add_fd(int fd, bool want_read, bool want_write);

    // returns list of events
    std::vector<PollEvent> poll(int timeout_ms);

private:
    std::vector<pollfd> pfds_;
    std::unordered_map<int, std::size_t> index_;
};

}
