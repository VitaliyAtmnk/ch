#pragma once
#include <cstdint>

namespace net {

class TcpListener {
public:
    TcpListener() = default;
    ~TcpListener();

    TcpListener(const TcpListener&) = delete;
    TcpListener& operator=(const TcpListener&) = delete;

    bool open(int port, int backlog);
    int fd() const noexcept { return fd_; }

    // Returns accepted client fd, or -1 if none (nonblocking).
    int accept_one();

private:
    int fd_ = -1;
    static bool set_nonblocking(int fd);
};

}