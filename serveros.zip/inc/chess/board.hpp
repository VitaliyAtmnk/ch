#pragma once
#include <array>
#include <string>

namespace chess
{

    enum class Color
    {
        White,
        Black
    };

    struct Square
    {
        int file = -1; // 0..7 (a..h)
        int rank = -1; // 0..7 (1..8)
    };

    struct MoveResult
    {
        bool ok = false;
        std::string reason; // "bad_coord", "not_your_turn", "need_promotion", "illegal_move", "checkmate", ...
    };

    class Board
    {
    public:
        Board(); // start position

        Color turn() const noexcept { return turn_; }

        // Validate+apply from->to (and optional promo 'q','r','b','n' for pawn promotion).
        MoveResult make_move(Color mover_color, const std::string &from, const std::string &to, const std::string &promo);

        // Evaluate if side to move has legal moves; used for mate/stalemate.
        bool has_any_legal_move(Color side) const;

        bool in_check(Color side) const;

        std::string to_fen() const;

        static bool parse_square(const std::string &s, Square &out);

    private:
        // board_[rank][file], rank 0 = '1'
        std::array<std::array<char, 8>, 8> board_{};

        Color turn_ = Color::White;

        // Castling rights
        bool w_k_ = true, w_q_ = true, b_k_ = true, b_q_ = true;

        // En-passant target square; file/rank = -1 means none
        int ep_file_ = -1;
        int ep_rank_ = -1;

        int halfmove_ = 0;
        int fullmove_ = 1;

        // helpers
        static bool is_white(char p);
        static bool is_black(char p);
        static bool is_empty(char p);
        static Color piece_color(char p);

        static char promo_piece(Color mover, char promo);

        bool square_attacked(int file, int rank, Color by) const;
        Square find_king(Color side) const;

        // pseudo move validation + apply on copy to test check
        MoveResult validate_basic(Color mover, Square a, Square b, char promo) const;
        Board after_move(Square a, Square b, char promo) const;

        // piece-specific
        bool path_clear(Square a, Square b) const;

        // special moves
        bool is_castle_move(char piece, Square a, Square b) const;
        MoveResult validate_castle(Color mover, Square a, Square b) const;
        Board apply_castle(Color mover, Square a, Square b) const;

        bool is_enpassant(Color mover, char piece, Square a, Square b) const;
    };

} // namespace chess
